from flask import Flask, request, jsonify, send_from_directory
import os
import json
import tempfile
from test5 import DerivativeTradeExtractor, validate_with_deepseek
from flask_cors import CORS

app = Flask(__name__, 
            static_folder="../frontend",
            template_folder="../frontend")
CORS(app)  # Enable CORS for all routes
extracted_versions = {}
@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory(app.static_folder, path)

@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    version = request.form.get('version', '1')  # Default to version 1 if not provided
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and (file.filename.endswith('.pdf') or file.filename.endswith('.docx')):
        # Create a temporary file to save the uploaded file
        temp_dir = tempfile.mkdtemp()
        file_path = os.path.join(temp_dir, file.filename)
        file.save(file_path)
        
        try:
            # Use the existing extractor to process the file
            extractor = DerivativeTradeExtractor()
            extracted_data = extractor.extract_from_pdf(file_path)
            
            # Validate the extracted data using only the latest version data
            validation_results = validate_with_deepseek(extracted_data)
            
            # If a previous version exists, compare data
            previous_version_data = extracted_versions.get(str(int(version) - 1))  # Get the previous version data if available
            changes = compare_versions(previous_version_data, extracted_data) if previous_version_data else []

            # Save the extracted data and validation results for this version
            extracted_versions[version] = {
                'extracted_data': extracted_data,
                'validation_results': validation_results,
                'changes': changes  # Store changes for comparison
            }
            
            # Clean up the temporary file
            os.remove(file_path)
            os.rmdir(temp_dir)
            
            # Return the results with proper content type
            response = jsonify({
                'success': True,
                'extracted_data': extracted_data,
                'validation_results': validation_results,
                'version': version,
                'all_versions': extracted_versions,  # Send all versions for the frontend
            })
            response.headers['Content-Type'] = 'application/json'
            return response
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    else:
        return jsonify({'error': 'Invalid file type. Please upload a PDF or DOCX file'}), 400


def compare_versions(previous_version_data, new_version_data):
    """
    Compare two versions of extracted data and return the changed parameters.
    """
    changes = []
    for param in new_version_data:
        if param in previous_version_data and new_version_data[param] != previous_version_data[param]:
            changes.push({
                'parameter': param,
                'old_value': previous_version_data[param],
                'new_value': new_version_data[param]
            })
    return changes

@app.route('/api/versions', methods=['GET'])
def get_versions():
    return jsonify({
        'versions': extracted_versions
    })

@app.route('/api/email-access', methods=['POST'])
def email_access():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    termsheet_id = data.get('termsheetId')
    
    if not email or not password or not termsheet_id:
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        from test5 import find_and_extract_termsheet_from_pdf
        result = find_and_extract_termsheet_from_pdf(email, password, termsheet_id)
        
        if not result:
            return jsonify({'error': 'No termsheet found or extraction failed'}), 404
            
        return jsonify({
            'success': True,
            'data': result
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/chat-access', methods=['POST'])
def chat_access():
    data = request.json
    phone = data.get('phone')
    otp = data.get('otp')
    termsheet_id = data.get('termsheetId')
    
    if not phone or not otp or not termsheet_id:
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        from test5 import find_and_extract_termsheet_from_telegram
        
        # These should be configured properly in a production environment
        api_id = 23364361  # From test5.py
        api_hash = '5c452d22c18f86ae2013cfa66f140d97'  # From test5.py
        chat_identifier = 6163289640  # From test5.py
        
        result = find_and_extract_termsheet_from_telegram(
            api_id=api_id,
            api_hash=api_hash,
            chat_identifier=chat_identifier,
            termsheet_keyword=termsheet_id
        )
        
        if not result.get("extracted_data"):
            return jsonify({'error': 'No termsheet found or extraction failed'}), 404
            
        return jsonify({
            'success': True,
            'data': result
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/save-feedback', methods=['POST'])
def save_feedback():
    data = request.json
    
    if not data:
        return jsonify({'error': 'No feedback data provided'}), 400
    
    try:
        import datetime
        
        # Generate a timestamp for the filename
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"validation_feedback_{ts}.json"
        filepath = os.path.join(os.path.dirname(__file__), filename)
        
        # Save the feedback data to a JSON file
        with open(filepath, "w") as f:
            json.dump(data, f, indent=2)
            
        return jsonify({
            'success': True,
            'message': f'Feedback saved to {filename}'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
