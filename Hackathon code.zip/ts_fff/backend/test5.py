import os
import re
import PyPDF2
import pdfplumber
import pytesseract
from pdf2image import convert_from_path
import pandas as pd
import logging
import datetime
from tabulate import tabulate
import json
import spacy
from dateutil import parser as dateparser  # For free-form date parsing
import os
import json
import openai 
from openai import OpenAI 
from tabulate import tabulate# Add this import
from rich.console import Console
from rich.table import Table
from rich import box
import tempfile
import imaplib
import email
from email.header import decode_header
from typing import Dict, Any, Set,List
import pprint
import tempfile
from typing import Any, Dict, Optional
from telethon.sync import TelegramClient
from telethon.tl.types import InputMessagesFilterDocument
# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# instantiate DeepSeek client
client = OpenAI(
    api_key= "sk-215d925b64e44893acc2d2ed3f3aa8cf",
    base_url='https://api.deepseek.com'
)

class DerivativeTradeExtractor:
    def __init__(self):
        # Load spaCy NLP model (used for both date and parameter extraction fallback)
        try:
            self.nlp = spacy.load("en_core_web_sm")
            logger.info("Successfully loaded spaCy model en_core_web_sm")
        except Exception as e:
            logger.warning("en_core_web_sm not found. Installing...")
            import subprocess
            subprocess.call("python -m spacy download en_core_web_sm", shell=True)
            self.nlp = spacy.load("en_core_web_sm")
        
        # Define mapping for date fields to context keywords for NLP extraction
        self.date_map = {
            'trade_date': ['trade date', 'trade', 'transaction date'],
            'expiry_date': ['expiry date', 'expiry', 'expiration', 'maturity'],
            'delivery_date': ['delivery date', 'delivery', 'settlement', 'payment date']
        }
        
        # Define regex patterns for each required parameter (general and custom formats)
        self.parameters = {
            # Custom date pattern for "DD Month YYYY" format
            'trade_date': r'(?i)trade\s*date\s*(\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4})',
            'ref_spot_price': r'(?i)(?:reference\s*spot\s*price|ref\s*spot\s*price|spot\s*price|reference\s*price)[\s:]+([\d.,]+)',
            'notional_amount': r'(?i)notional\s*amount\s*((?:[A-Z]{3}\s*)?[\d,]+(?:,\d{3})*(?:\.\d+)?)',
            'strike_price': r'(?i)strike\s*price\s*([\d.,]+)',
            'option_type': r'(?i)option\s*type\s*(European\s*(?:Call|Put)|American\s*(?:Call|Put)|Call|Put)',
            # Custom date pattern for "DD Month YYYY" format
            'expiry_date': r'(?i)expiry\s*date\s*(\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4})',
            'business_calendar': r'(?i)business\s*calendar\s*([A-Za-z\s&]+)',
            # Custom date pattern for "DD Month YYYY" format
            'delivery_date': r'(?i)delivery\s*date\s*(\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4})',
            'premium_rate': r'(?i)premium\s*rate\s*([^\n\r]*?)(?:of\s*Notional|\(|$)',
            'transaction_currency': r'(?i)transaction\s*currency\s*([A-Z]{3})',
            'counter_currency': r'(?i)counter\s*currency\s*([A-Z]{3})'
        }
        
        # Custom specific patterns tailored to your document format
        self.custom_formats = {
            'trade_date': r'(?:^|\n)Trade\s+Date\s+(\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4})',
            'ref_spot_price': r'(?:^|\n)Reference\s+Spot\s+Price\s+([\d.,]+)',
            'notional_amount': r'(?:^|\n)Notional\s+Amount\s+([^\n\r]*)',
            'strike_price': r'(?:^|\n)Strike\s+Price\s+([\d.,]+)',
            'option_type': r'(?:^|\n)Option\s+Type\s+([^\n\r]*)',
            'expiry_date': r'(?:^|\n)Expiry\s+Date\s+(\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4})',
            'delivery_date': r'(?:^|\n)Delivery\s+Date\s+(\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4})',
            'business_calendar': r'(?:^|\n)Business\s+Calendar\s+([^\n\r]*)',
            'premium_rate': r'(?:^|\n)Premium\s+Rate\s+([^\n\r]*)',
            'transaction_currency': r'(?:^|\n)Transaction\s+Currency\s+([A-Z]{3})',
            'counter_currency': r'(?:^|\n)Counter\s+Currency\s+([A-Z]{3})'
        }
        
        # Patterns for dates in the format DD MMMM YYYY
        self.date_patterns = [
            r'\b(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{4})\b',
        ]
    
    def extract_from_pdf(self, pdf_path):
        """Main method to extract parameters from a PDF"""
        logger.info(f"Processing PDF: {pdf_path}")
        
        # Try direct text extraction first
        text = self._extract_text_from_pdf(pdf_path)
        
        # If minimal text was extracted, it might be a scanned PDF
        if len(text.strip()) < 100:
            logger.info("Little text found, attempting OCR processing")
            text = self._perform_ocr(pdf_path)
            
        logger.info(f"Extracted text sample: {text[:200]}...")
        
        # Extract parameters from text using regex
        results = self._extract_parameters(text)
        
        # For date fields that were not found, try using NLP-based extraction
        for field in ['trade_date', 'expiry_date', 'delivery_date']:
            if field not in results or not results[field]:
                nlp_date = self._extract_date_with_nlp(field, text)
                if nlp_date:
                    results[field] = nlp_date
                    logger.info(f"NLP provided {field}: {nlp_date}")
        
        # For non-date parameters missing from regex extraction, use NLP fallback
        fallback_fields = ["ref_spot_price", "notional_amount", "strike_price", "option_type", "transaction_currency", "counter_currency"]
        for field in fallback_fields:
            # Map field keys to our standardized key names
            key = field if field not in ['transaction_currency', 'counter_currency'] else field
            if key not in results or not results[key]:
                nlp_value = self._extract_param_with_nlp(key, text)
                if nlp_value:
                    results[key] = nlp_value
                    logger.info(f"NLP fallback extracted {key}: {nlp_value}")
        
        # Post-process results for consistency and standardization
        results = self._postprocess_results(results)
        
        # Print the results in a nicely formatted table
        self.print_extraction_results(results, pdf_path)
        return results
    
    def _extract_text_from_pdf(self, pdf_path):
        """Extract text using both PyPDF2 and pdfplumber for best results"""
        text = ""
        try:
            with open(pdf_path, "rb") as file:
                reader = PyPDF2.PdfReader(file)
                for page_num in range(len(reader.pages)):
                    page_text = reader.pages[page_num].extract_text()
                    if page_text:
                        text += page_text + "\n"
            logger.info(f"Extracted {len(text)} characters with PyPDF2")
        except Exception as e:
            logger.error(f"Error extracting text with PyPDF2: {e}")
        
        if len(text.strip()) < 100:
            try:
                with pdfplumber.open(pdf_path) as pdf:
                    for page in pdf.pages:
                        page_text = page.extract_text() or ""
                        text += page_text + "\n"
                        tables = page.extract_tables()
                        for table in tables:
                            for row in table:
                                if len(row) >= 2 and row[0] and row[1]:
                                    text += f"{row[0]}: {row[1]}\n"
                                else:
                                    row_text = " ".join([str(cell) for cell in row if cell is not None])
                                    text += row_text + "\n"
                logger.info(f"Extracted {len(text)} characters with pdfplumber")
            except Exception as e:
                logger.error(f"Error extracting text with pdfplumber: {e}")
        return text
    
    def _perform_ocr(self, pdf_path):
        """Perform OCR on PDF pages"""
        logger.info("Starting OCR processing")
        text = ""
        try:
            images = convert_from_path(pdf_path)
            for i, image in enumerate(images):
                logger.info(f"Processing page {i+1} with OCR")
                page_text = pytesseract.image_to_string(image)
                text += page_text + "\n"
            logger.info(f"OCR completed, extracted {len(text)} characters")
        except Exception as e:
            logger.error(f"Error during OCR processing: {e}")
        return text
    
    def _extract_parameters(self, text):
        """Extract financial parameters from text using regex patterns"""
        results = {}
        text = self._preprocess_text(text)
        dates = self._extract_dates_dd_month_yyyy(text)
        logger.info(f"Extracted dates: {dates}")
        
        # Use custom formats first
        for param_name, pattern in self.custom_formats.items():
            matches = re.findall(pattern, text, re.IGNORECASE | re.MULTILINE)
            if matches:
                results[param_name] = matches[0].strip()
                logger.info(f"Found {param_name}: {results[param_name]} using custom format")
        
        # Then use general patterns for missing fields
        for param_name, pattern in self.parameters.items():
            if param_name not in results:
                matches = re.findall(pattern, text, re.IGNORECASE | re.MULTILINE)
                if matches:
                    results[param_name] = matches[0].strip()
                    logger.info(f"Found {param_name}: {results[param_name]} using general pattern")
        
        # Map date context using our date_map
        for field, keywords in self.date_map.items():
            if field not in results and dates:
                for date_val, date_ctx in dates:
                    if any(kw in date_ctx.lower() for kw in keywords):
                        results[field] = date_val
                        logger.info(f"Assigned date {date_val} to {field} based on context: {date_ctx}")
                        break
        
        return results
    
    def _extract_dates_dd_month_yyyy(self, text):
        """Extract dates in the format DD Month YYYY and return with context"""
        dates_with_context = []
        for pattern in self.date_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                day = match.group(1).zfill(2)
                month = match.group(2)
                year = match.group(3)
                month_num = self._month_to_number(month)
                formatted_date = f"{year}-{month_num}-{day}"
                start_pos = max(0, match.start() - 30)
                end_pos = min(len(text), match.end() + 30)
                context = text[start_pos:end_pos]
                dates_with_context.append((formatted_date, context))
                logger.info(f"Extracted date: {formatted_date} with context: {context}")
        return dates_with_context

    def _extract_date_with_nlp(self, field, text):
        """
        Use spaCy NLP to extract a date for the given field if missing.
        Scans sentences containing context keywords and looks for DATE entities.
        """
        doc = self.nlp(text)
        keywords = self.date_map.get(field, [])
        for sent in doc.sents:
            if any(kw in sent.text.lower() for kw in keywords):
                for ent in sent.ents:
                    if ent.label_ == "DATE":
                        try:
                            parsed_date = dateparser.parse(ent.text, fuzzy=True)
                            if parsed_date:
                                formatted_date = parsed_date.strftime("%Y-%m-%d")
                                logger.info(f"NLP extracted {field}: {formatted_date} from sentence: {sent.text}")
                                return formatted_date
                        except Exception as ex:
                            logger.error(f"Error parsing date '{ent.text}': {ex}")
        return None
    
    def _extract_param_with_nlp(self, field, text):
        """
        Fallback NLP method for extracting non-date parameters.
        Scans sentences for keywords specific to the field and uses simple regex extraction.
        """
        fallback_map = {
            'ref_spot_price': ["reference spot price", "ref spot price", "spot price"],
            'notional_amount': ["notional amount"],
            'strike_price': ["strike price"],
            'option_type': ["option type"],
            'transaction_currency': ["transaction currency"],
            'counter_currency': ["counter currency"]
        }
        keywords = fallback_map.get(field, [])
        doc = self.nlp(text)
        for sent in doc.sents:
            if any(kw in sent.text.lower() for kw in keywords):
                if field in ['ref_spot_price', 'notional_amount', 'strike_price']:
                    match = re.search(r'([\d,]+(?:\.\d+)?)', sent.text)
                    if match:
                        return match.group(1)
                elif field == 'option_type':
                    match = re.search(r'option\s*type\s*([\w\s]+)', sent.text, re.IGNORECASE)
                    if match:
                        return match.group(1).strip()
                elif field in ['transaction_currency', 'counter_currency']:
                    match = re.search(r'([A-Z]{3})', sent.text)
                    if match:
                        return match.group(1)
        return None

    def _month_to_number(self, month_name):
        """Convert month name to number (with leading zero)"""
        months = {
            'january': '01', 'jan': '01',
            'february': '02', 'feb': '02',
            'march': '03', 'mar': '03',
            'april': '04', 'apr': '04',
            'may': '05',
            'june': '06', 'jun': '06',
            'july': '07', 'jul': '07',
            'august': '08', 'aug': '08',
            'september': '09', 'sep': '09',
            'october': '10', 'oct': '10',
            'november': '11', 'nov': '11',
            'december': '12', 'dec': '12'
        }
        return months.get(month_name.lower(), '01')
    
    def _preprocess_text(self, text):
        """Clean and normalize text for processing"""
        text = re.sub(r'\s+', ' ', text)
        text = text.replace('\t', ' ')
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        return text
    
    def _postprocess_results(self, results):
        """Clean and format the extracted parameters"""
        # Standardize currency keys
        if 'transaction_currency' in results and 'transaction_ccy' not in results:
            results['transaction_ccy'] = results.pop('transaction_currency')
        if 'counter_currency' in results and 'counter_ccy' not in results:
            results['counter_ccy'] = results.pop('counter_currency')
        
        # Clean monetary values
        money_fields = ['ref_spot_price', 'notional_amount', 'strike_price', 'premium_rate']
        for field in money_fields:
            if field in results:
                value = results[field]
                currency_code = ""
                currency_match = re.search(r'\b([A-Z]{3})\b', value)
                if currency_match:
                    currency_code = currency_match.group(1) + " "
                numeric_part = re.search(r'([\d,]+(?:\.\d+)?)', value)
                if numeric_part:
                    results[field] = currency_code + numeric_part.group(1)
                else:
                    results[field] = value
                if field == 'premium_rate' and '%' in value:
                    percentage = re.search(r'([\d\.]+)\s*%', value)
                    if percentage:
                        results[field] = percentage.group(1) + "%"
        
        # Standardize option type
        if 'option_type' in results:
            option_type = results['option_type'].lower()
            if 'call' in option_type:
                if 'european' in option_type:
                    results['option_type'] = 'European Call'
                elif 'american' in option_type:
                    results['option_type'] = 'American Call'
                else:
                    results['option_type'] = 'Call'
            elif 'put' in option_type:
                if 'european' in option_type:
                    results['option_type'] = 'European Put'
                elif 'american' in option_type:
                    results['option_type'] = 'American Put'
                else:
                    results['option_type'] = 'Put'
        
        for field in ['transaction_ccy', 'counter_ccy']:
            if field in results:
                results[field] = results[field].upper()
        
        return results
    
    def print_extraction_results(self, results, filename=None):
        """Print extraction results in a nicely formatted way"""
        print("\n" + "=" * 80)
        print(f"EXTRACTION RESULTS" + (f" for {os.path.basename(filename)}" if filename else ""))
        print("=" * 80)
        
        print("\nALL EXTRACTED DATES (for verification):")
        for date_param in ['trade_date', 'expiry_date', 'delivery_date']:
            if date_param in results:
                raw_date = results[date_param]
                if re.match(r'\d{4}-\d{2}-\d{2}', raw_date):
                    try:
                        date_obj = datetime.datetime.strptime(raw_date, '%Y-%m-%d')
                        formatted_date = date_obj.strftime('%d %B %Y')
                        print(f"  {date_param.replace('_', ' ').title()}: {raw_date} => {formatted_date}")
                    except ValueError:
                        print(f"  {date_param.replace('_', ' ').title()}: {raw_date}")
                else:
                    print(f"  {date_param.replace('_', ' ').title()}: {raw_date}")
        
        data = []
        expected_fields = ["trade_date", "expiry_date", "delivery_date", "ref_spot_price", 
                           "notional_amount", "strike_price", "option_type", "premium_rate", 
                           "transaction_ccy", "counter_ccy", "business_calendar"]
        
        for field in expected_fields:
            if field in results:
                value = results[field]
                if field.endswith('_date') and re.match(r'\d{4}-\d{2}-\d{2}', value):
                    try:
                        date_obj = datetime.datetime.strptime(value, '%Y-%m-%d')
                        value = date_obj.strftime('%d %B %Y')
                    except ValueError:
                        pass
                data.append([field, value])
            else:
                data.append([field, "NOT FOUND"])
                
        print("\nEXTRACTED PARAMETERS:")
        print(tabulate(data, headers=["Parameter", "Value"], tablefmt="fancy_grid"))
        
        print("\nJSON Format:")
        print(json.dumps({field: value for field, value in data if "NOT FOUND" not in value}, indent=2))
        print("=" * 80 + "\n")
def find_and_extract_termsheet_from_pdf(
    email_address: str,
    password: str,
    termsheet_id: str,
    mail_server: str = "imap.gmail.com"
) -> Dict[str, Any]:
    """
    Connects to the inbox, finds the latest email whose SUBJECT contains termsheet_id,
    downloads its PDF attachment(s), runs your PDF extractor on it, then returns
    both the raw data and its DeepSeek validation + email metadata.
    """
    temp_dir = tempfile.mkdtemp()
    try:
        mail = imaplib.IMAP4_SSL(mail_server)
        mail.login(email_address, password)
        mail.select("inbox")

        status, messages = mail.search(None, f'SUBJECT "{termsheet_id}"')
        if status != 'OK' or not messages[0]:
            print(f"No emails found with termsheet ID: {termsheet_id}")
            return {}

        email_ids = messages[0].split()
        latest = email_ids[-1]
        status, msg_data = mail.fetch(latest, "(RFC822)")
        raw_email = msg_data[0][1]
        msg = email.message_from_bytes(raw_email)

        # decode subject & sender/date
        subject = decode_header(msg["Subject"])[0][0]
        if isinstance(subject, bytes):
            subject = subject.decode()
        sender = msg.get("From")
        date   = msg.get("Date")

        extracted = {}
        attachments = []
        # walk attachments
        for part in msg.walk():
            cd = str(part.get("Content-Disposition"))
            if "attachment" in cd:
                fn = part.get_filename()
                if fn and fn.lower().endswith(".pdf"):
                    # decode filename
                    fn = decode_header(fn)[0][0]
                    if isinstance(fn, bytes):
                        fn = fn.decode()
                    path = os.path.join(temp_dir, fn)
                    with open(path, "wb") as f:
                        f.write(part.get_payload(decode=True))
                    attachments.append(fn)

                    # use your extractor
                    extractor = DerivativeTradeExtractor()
                    data = extractor.extract_from_pdf(path)
                    # pick the file with most fields found
                    if not extracted or len(data) > len(extracted):
                        extracted = data

        mail.close()
        mail.logout()

        if not extracted:
            print("No PDF data extracted.")
            return {}

        # run DeepSeek validation
        validation = validate_with_deepseek(extracted)

        return {
            "extracted_data": extracted,
            "validation_results": validation,
            "email_metadata": {
                "subject": subject,
                "sender": sender,
                "date": date,
                "attachments": attachments
            }
        }
    except Exception as e:
        print(f"Error fetching termsheet from email: {e}")
        return {}
    finally:
        # cleanup
        try:
            os.rmdir(temp_dir)
        except:
            pass
def find_and_extract_termsheet_from_telegram(
    api_id: int,
    api_hash: str,
    chat_identifier: str,
    termsheet_keyword: str,
    download_dir: Optional[str] = None
) -> Dict[str, Any]:
    """
    Connects to Telegram via Telethon, searches `chat_identifier` for the
    most recent message containing `termsheet_keyword` and a PDF document,
    downloads it, and extracts parameters using DerivativeTradeExtractor.

    Returns a dict with:
      - 'extracted_data': the parameter dict from the PDF
      - 'telegram_metadata': info about the message (id, date, sender)
    """
    # prepare download directory
    if not download_dir:
        download_dir = tempfile.mkdtemp()

    # start Telethon client (session file will be named 'session_telegram')
    client = TelegramClient('session_telegram', api_id, api_hash)
    client.start()

    extracted = {}
    metadata: Dict[str, Any] = {}

    # iterate messages in reverse chronological order, filtering only documents
    for message in client.iter_messages(chat_identifier, filter=InputMessagesFilterDocument):
        # only consider PDFs whose caption/text mentions our keyword
        caption = (message.message or "").lower()
        if message.document.mime_type == 'application/pdf' and termsheet_keyword.lower() in caption:
            # download the PDF
            file_path = message.download_media(file=download_dir)
            # extract using your existing extractor
            extractor = DerivativeTradeExtractor()
            extracted = extractor.extract_from_pdf(file_path)
            # record a few bits of metadata
            metadata = {
                "message_id": message.id,
                "chat": chat_identifier,
                "date": message.date.isoformat(),
                "sender_id": message.sender_id,
                "file_path": file_path
            }
            break

    client.disconnect()
    return {
        "extracted_data": extracted,
        "telegram_metadata": metadata
    }        
def load_master_values(path: str = "master_values.xlsx") -> Dict[str, Set[str]]:
    """
    Reads an Excel file (default: master_values.xlsx) and returns a map
    param_key -> set of allowed values.  It will auto‑detect which two
    columns in the sheet represent “parameter name” and “allowed value.”
    """
    try:
        df = pd.read_excel(path, engine="openpyxl")
    except Exception as e:
        logger.error(f"Failed to read master sheet '{path}': {e}")
        return {}

    # Normalize column names
    cols = [c.strip().lower() for c in df.columns]

    # Attempt to find the parameter column
    param_candidates = ["parameter", "parameters", "param", "field", "name"]
    param_col = None
    for cand in param_candidates:
        if cand in cols:
            param_col = df.columns[cols.index(cand)]
            break
    if not param_col:
        # fallback to first column
        param_col = df.columns[0]

    # Attempt to find the value column
    value_candidates = ["value", "allowed", "allowedvalue", "allowed_value", "allowed values"]
    value_col = None
    for cand in value_candidates:
        if cand in cols:
            value_col = df.columns[cols.index(cand)]
            break
    if not value_col and len(df.columns) > 1:
        # fallback to second column
        value_col = df.columns[1]
    if not value_col:
        value_col = param_col  # worst case, they'll both be same

    master: Dict[str, Set[str]] = {}
    for _, row in df.iterrows():
        raw_param = str(row.get(param_col, "")).strip()
        raw_val   = str(row.get(value_col, "")).strip()
        if not raw_param or not raw_val:
            continue

        # normalize e.g. "Trade Date" -> "trade_date"
        key = re.sub(r"[^\w\s]", "", raw_param)       # drop punctuation
        key = re.sub(r"\s+", "_", key).lower()        # spaces -> underscore

        master.setdefault(key, set()).add(raw_val)

    logger.info(f"Loaded master values for parameters: {list(master.keys())}")
    return master
# def infer_column_mapping_via_deepseek(
#     extractor_keys: list[str],
#     master_columns: list[str]
# ) -> dict[str,str]:
#     """
#     Use DeepSeek to map each snake_case extractor key to the best-matching
#     column header from the master sheet.
#     """
#     prompt = f"""
# You are a data-mapping assistant.  I have two lists:
# 1) My extractor parameters (snake_case):
# {json.dumps(extractor_keys, indent=2)}

# 2) The raw column headers from my master Excel sheet:
# {json.dumps(master_columns, indent=2)}

# For each extractor parameter, pick the one master‐sheet header that best
# matches (allowing for slight naming differences), or return an empty
# string if none matches.  Reply *only* with a JSON object of the form:

# {{"trade_date": "Trade Date", "ref_spot_price": "Reference Spot Price", …}}
# """
#     resp = client.chat.completions.create(
#         model="deepseek-reasoner",
#         temperature=0.0,
#         max_tokens=1500,
#         messages=[
#             {"role":"system", "content":"Output pure JSON only."},
#             {"role":"user",   "content":prompt}
#         ]
#     )
#     raw = resp.choices[0].message.content
#     cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw).strip()
#     try:
#         return json.loads(cleaned)
#     except json.JSONDecodeError:
#         logger.error("Failed to parse mapping JSON from DeepSeek:\n" + raw)
#         return {}
#     return mapping      
def validate_with_deepseek(
    parameters: dict[str, Any],
    master_path: str = "master_values.xlsx"
) -> dict[str, Any]:
    """
    Use DeepSeek to validate each extracted parameter.
    - Master values shown for reference only (not used for status).
    - Status depends entirely on DeepSeek's judgment.
    """

    # Load master values for display
    master = load_master_values(master_path)
    validation_results = {}

    # Initialize with extracted and master values
    for key, val in parameters.items():
        validation_results[key] = {
            "value": val,
            "master_list": sorted(master.get(key, set())),
            "match": None,  # will be set based on DeepSeek response
            "comment": "Pending validation..."
        }

    # Prepare prompt for DeepSeek
    try:
        prompt = (
            "You are a financial domain expert at Barclays. Evaluate the following extracted "
            "term sheet parameters for correctness, consistency, and financial logic. "
            "For each parameter, return:\n\n"
            "{\n"
            "  \"validation_results\": {\n"
            "    \"param_name\": {\n"
            "      \"match\": true or false,\n"
            "      \"comment\": \"Your expert comment\"\n"
            "    }, ...\n"
            "  }\n"
            "}\n\n"
            "Respond in pure JSON format. Do not include any markdown."
        )

        message_content = json.dumps(parameters, indent=2)
        response = client.chat.completions.create(
            model="deepseek-reasoner",
            temperature=0.4,
            max_tokens=1500,
            messages=[
                {"role": "system", "content": "You are a financial validation AI."},
                {"role": "user", "content": f"{prompt}\n\n{message_content}"}
            ]
        )

        raw = response.choices[0].message.content
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)
        deepseek_results = json.loads(cleaned).get("validation_results", {})

        # Inject DeepSeek match and comment into each result
        for key, info in deepseek_results.items():
            if key in validation_results:
                validation_results[key]["match"] = info.get("match", None)
                validation_results[key]["comment"] = info.get("comment", "—")

    except Exception as e:
        logger.warning(f"DeepSeek validation failed: {e}")
        for key in validation_results:
            validation_results[key]["match"] = None
            validation_results[key]["comment"] = "DeepSeek error or timeout"

    return {"validation_results": validation_results}


def collect_feedback(report):
    """
    Walk the user through each parameter and record whether they agree
    with the validation status, plus any comment if they disagree.
    Saves feedback to a timestamped JSON file.
    """
    if not isinstance(report, dict):
        print("\n⚠️ Cannot collect feedback: validation output is not structured JSON.\n")
        return None

    print("\n" + "-"*30 + " Feedback " + "-"*30)
    feedback = {}
    for param, info in report.items():
        # handle both dict and fallback-string cases
        if isinstance(info, dict):
            val    = info.get("value", "")
            status = info.get("status", "")
        else:
            val    = ""
            status = str(info)

        print(f"\nParameter: {param}")
        print(f"  Extracted value : {val}")
        print(f"  Validation status: {status}")

        # prompt for agreement
        while True:
            ans = input("   Do you agree with this status? (y/n): ").strip().lower()
            if ans in ("y", "n"):
                break
            print("   Please enter 'y' or 'n'.")

        if ans == "y":
            feedback[param] = {"agree": True, "comment": ""}
        else:
            comment = input("   Enter your correction or comment: ").strip()
            feedback[param] = {"agree": False, "comment": comment}

    # save feedback
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = f"validation_feedback_{ts}.json"
    with open(fname, "w") as f:
        json.dump(feedback, f, indent=2)
    print(f"\n✅ Feedback saved to {fname}\n")
    return feedback

def process_multiple_pdfs(directory):
    """Process all PDFs in a directory and return aggregated results"""
    extractor = DerivativeTradeExtractor()
    all_results = []
    
    for filename in os.listdir(directory):
        if filename.lower().endswith('.pdf'):
            pdf_path = os.path.join(directory, filename)
            try:
                results = extractor.extract_from_pdf(pdf_path)
                results['filename'] = filename
                all_results.append(results)
                logger.info(f"Successfully processed {filename}")
            except Exception as e:
                logger.error(f"Error processing {filename}: {e}")
    
    if all_results:
        df = pd.DataFrame(all_results)
        csv_path = os.path.join(directory, "extracted_derivative_parameters.csv")
        df.to_csv(csv_path, index=False)
        logger.info(f"Results saved to {csv_path}")
        
        print("\n" + "=" * 80)
        print(f"SUMMARY OF PROCESSED FILES ({len(all_results)} files)")
        print("=" * 80)
        
        summary_data = []
        for result in all_results:
            row = [
                result.get('filename', 'Unknown'),
                result.get('trade_date', 'N/A'),
                result.get('expiry_date', 'N/A'),
                result.get('option_type', 'N/A'),
                f"{result.get('transaction_ccy', 'N/A')}/{result.get('counter_ccy', 'N/A')}"
            ]
            summary_data.append(row)
            
        print(tabulate(summary_data, 
                       headers=["Filename", "Trade Date", "Expiry Date", "Option Type", "Currency Pair"], 
                       tablefmt="fancy_grid"))
        print(f"\nDetailed results saved to: {csv_path}")
        print("=" * 80 + "\n")
        
        return df
    else:
        logger.warning("No results extracted from PDFs")
        return None

from rich.console import Console
from rich.table import Table
from rich import box

def print_validation_report(
    report: dict,
    extracted: dict,
    master_path: str = "master_values.xlsx"
):
    console = Console()

    # 1) Extracted Values
    table1 = Table(title="1) Extracted Values", box=box.ROUNDED)
    table1.add_column("Parameter", style="cyan", no_wrap=True)
    table1.add_column("Extracted", overflow="fold")
    for param, val in extracted.items():
        table1.add_row(param, str(val))
    console.print(table1)

    # Load master‐sheet values
    master_map = load_master_values(master_path)

    # 2) Master-sheet Allowed Values
    table2 = Table(title="2) Master-sheet Allowed Values", box=box.ROUNDED)
    table2.add_column("Parameter", style="cyan", no_wrap=True)
    table2.add_column("Allowed (master_list)", overflow="fold", style="yellow")
    for param in extracted.keys():
        allowed = master_map.get(param, set())
        allowed_str = ", ".join(sorted(allowed)) if allowed else "—"
        table2.add_row(param, allowed_str)
    console.print(table2)

    # 3) Match / Mismatch
    vr = report.get("validation_results", {})
    table3 = Table(title="3) Match / Mismatch", box=box.ROUNDED)
    table3.add_column("Parameter", style="cyan", no_wrap=True)
    table3.add_column("Match?", justify="center")
    for param in extracted.keys():
        info = vr.get(param, {})
        # check either map_match or match boolean
        matched = bool(info.get("map_match") or info.get("match"))
        icon = "[green]✔[/green]" if matched else "[red]✘[/red]"
        table3.add_row(param, icon)
    console.print(table3)

    # 4) DeepSeek Comments
    table4 = Table(title="4) DeepSeek Comments", box=box.ROUNDED)
    table4.add_column("Parameter", style="cyan", no_wrap=True)
    table4.add_column("DS Comment", overflow="fold")
    table4.add_column("Map Comment", overflow="fold")
    for param in extracted.keys():
        info = vr.get(param, {})
        ds_comment  = info.get("comment") or info.get("message") or "—"
        map_comment = info.get("map_comment") or "—"
        table4.add_row(param, ds_comment, map_comment)
    console.print(table4)

    # 5) Errors
    if errors := report.get("errors"):
        err_tbl = Table(title="Errors", box=box.ROUNDED, header_style="bold red")
        err_tbl.add_column("Field")
        err_tbl.add_column("Message", overflow="fold")
        for e in errors:
            err_tbl.add_row(e.get("field","—"), e.get("message",""))
        console.print(err_tbl)

    # 6) Warnings
    if warnings := report.get("warnings") or report.get("validation_notes",{}).get("warnings"):
        warn_tbl = Table(title="Warnings", box=box.ROUNDED, header_style="bold yellow")
        warn_tbl.add_column("Field")
        warn_tbl.add_column("Message", overflow="fold")
        for w in warnings:
            if isinstance(w, dict):
                fld = w.get("field","—"); msg = w.get("message","")
            else:
                fld, msg = "—", str(w)
            warn_tbl.add_row(fld, msg)
        console.print(warn_tbl)



if __name__ == "__main__":
    import os
    import json
    import getpass
    from pathlib import Path

    print("\n" + "*" * 80)
    print("PDF DERIVATIVE PARAMETER EXTRACTOR WITH DeepSeek VALIDATION")
    print("*" * 80)

    # Menu
    print("\nSelect input mode:")
    print("  1) Single PDF file")
    print("  2) Folder of PDFs")
    print("  3) Email attachment lookup")
    print("  4) Telegram chat lookup")  # new option
    choice = input("Enter choice (1/2/3/4): ").strip()

    if choice == "1":
        # Single file
        pdf_path = input("Enter the full path to the PDF file: ").strip()
        if not os.path.isfile(pdf_path):
            print(f"File not found: {pdf_path}")
            exit(1)

        extractor = DerivativeTradeExtractor()
        extracted = extractor.extract_from_pdf(pdf_path)

        print("\nDEEPSEEK VALIDATION REPORT:")
        report = validate_with_deepseek(extracted)
        print_validation_report(report, extracted)
        collect_feedback(report)

    elif choice == "2":
        # Directory of PDFs
        pdf_dir = input("Enter the directory containing PDFs: ").strip()
        if not os.path.isdir(pdf_dir):
            print(f"Directory not found: {pdf_dir}")
            exit(1)

        process_multiple_pdfs(pdf_dir)

    elif choice == "3":
        # Email mode
        email_addr   = input("Enter your email address: ").strip()
        password     = getpass.getpass("Enter your email password/app password: ")
        termsheet_id = input("Enter the Termsheet ID to search for in email subjects: ").strip()

        result = find_and_extract_termsheet_from_pdf(email_addr, password, termsheet_id)
        if not result:
            exit(1)

        print("\nEXTRACTED DATA:")
        print(json.dumps(result["extracted_data"], indent=2))

        print("\nEMAIL METADATA:")
        print(json.dumps(result["email_metadata"], indent=2))

        print("\nDEEPSEEK VALIDATION REPORT:")
        print_validation_report(result["validation_results"], result["extracted_data"])
        collect_feedback(result["validation_results"])

    elif choice == "4":
        # Telegram mode
        from telethon.sync import TelegramClient
        from telethon.tl.types import InputMessagesFilterDocument

        api_id          = 23364361
        api_hash        = '5c452d22c18f86ae2013cfa66f140d97'
        chat_identifier = 6163289640      # ← hard-coded Telethon ID
        keyword         = input("Enter the termsheet keyword to search for: ").strip()


        result = find_and_extract_termsheet_from_telegram(
            api_id=api_id,
            api_hash=api_hash,
            chat_identifier=chat_identifier,
            termsheet_keyword=keyword
        )
        if not result.get("extracted_data"):
            print("No PDF found or no data extracted.")
            exit(1)

        print("\nEXTRACTED DATA:")
        print(json.dumps(result["extracted_data"], indent=2))

        print("\nTELEGRAM METADATA:")
        print(json.dumps(result["telegram_metadata"], indent=2))

        print("\nDEEPSEEK VALIDATION REPORT:")
        report = validate_with_deepseek(result["extracted_data"])
        print_validation_report(report, result["extracted_data"])
        collect_feedback(report)

    else:
        print("Invalid choice. Exiting.")
        exit(1)