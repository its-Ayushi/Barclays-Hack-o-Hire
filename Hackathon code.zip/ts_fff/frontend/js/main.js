/**
 * Term Sheet Analyzer - Main JavaScript
 * 
 * Handles client-side functionality including file uploads, data validation,
 * and results display.
 */

document.addEventListener('DOMContentLoaded', function() {
    // Configuration
    const API_BASE_URL = '/api';
    let currentDocument = null;

    // Initialize application
    initEventListeners();
    initResultsPage();

    function initEventListeners() {
        // Navigation
        document.getElementById('uploadBtn')?.addEventListener('click', (e) => {
            e.preventDefault();
            showSection(document.getElementById('uploadSection'));
        });
        
        document.getElementById('emailBtn')?.addEventListener('click', (e) => {
            e.preventDefault();
            showSection(document.getElementById('emailSection'));
        });
        
        document.getElementById('chatBtn')?.addEventListener('click', (e) => {
            e.preventDefault();
            showSection(document.getElementById('chatSection'));
        });

        // File upload
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');
        
        if (dropZone && fileInput) {
            dropZone.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', function() { 
                if (this.files?.[0]) handleFileSelection(this.files[0]); 
            });
            
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropZone.addEventListener(eventName, preventDefaults, false);
            });

            ['dragenter', 'dragover'].forEach(eventName => {
                dropZone.addEventListener(eventName, () => dropZone.classList.add('active'), false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                dropZone.addEventListener(eventName, () => dropZone.classList.remove('active'), false);
            });

            dropZone.addEventListener('drop', (e) => {
                const file = e.dataTransfer.files[0];
                if (file) handleFileSelection(file);
            }, false);
        }

        // Form submissions
        document.getElementById('emailForm')?.addEventListener('submit', handleEmailSubmit);
        document.getElementById('chatForm')?.addEventListener('submit', handleChatSubmit);

        // Password toggle
        document.querySelectorAll('.toggle-password, .toggle-otp').forEach(button => {
            button.addEventListener('click', togglePasswordVisibility);
        });

        // Tab navigation
        document.querySelectorAll('.tab-btn').forEach(button => {
            button.addEventListener('click', handleTabClick);
        });

        // Export button
        document.getElementById('exportBtn')?.addEventListener('click', exportValidationData);
    }
    // Handle the form submission
    document.getElementById('upload-version-form').addEventListener('submit', function(event) {
        event.preventDefault();  // Prevent the form from reloading the page
    
        // Get the file and version from the form
        var file = document.getElementById('file').files[0];
        var version = document.getElementById('version').value;
    
        // Prepare the form data for upload
        var formData = new FormData();
        formData.append('file', file);
        formData.append('version', version);
    
        // Send the file to the server
        fetch('http://127.0.0.1:5000/api/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Terms uploaded and validated successfully!');
                updateValidationTable(data.all_versions);  // Pass all versions data to update the table
            } else {
                alert('Error: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error uploading file:', error);
            alert('An error occurred while uploading the file.');
        });
    });
    
    // Function to update the validation table with new data
    function updateValidationTable(allVersions) {
        // Get the validation table element
        var table = document.getElementById('validation-table');
    
        // Clear existing table content
        table.innerHTML = '';
    
        // Create the table header
        var headerRow = document.createElement('tr');
        var headers = ['Parameter'];
    
        // Dynamically create header for each version
        for (var version in allVersions) {
            headers.push('Version ' + version);
        }
        headers.push('Changed');  // Add "Changed" column to indicate if the parameter changed
    
        // Add headers to the table
        headers.forEach(headerText => {
            var th = document.createElement('th');
            th.textContent = headerText;
            headerRow.appendChild(th);
        });
        table.appendChild(headerRow);
    
        // Collect all parameters (union of all parameters from all versions)
        var allParameters = new Set();
        for (var version in allVersions) {
            var extractedData = allVersions[version].extracted_data;
            for (var param in extractedData) {
                allParameters.add(param);
            }
        }
    
        // Fill in the table rows
        allParameters.forEach(param => {
            var row = document.createElement('tr');
            
            // Create a cell for the parameter name
            var paramCell = document.createElement('td');
            paramCell.textContent = param;
            row.appendChild(paramCell);
    
            // Add extracted data for each version
            var changedFlag = false;  // Flag to track if the parameter changed between versions
            for (var version in allVersions) {
                var extractedDataCell = document.createElement('td');
                var extractedData = allVersions[version].extracted_data;
                extractedDataCell.textContent = extractedData[param] || 'N/A';
                row.appendChild(extractedDataCell);
    
                // Compare current version's data with previous version's data
                if (version > 1) {
                    var previousVersionData = allVersions[version - 1].extracted_data;
                    if (extractedData[param] !== previousVersionData[param]) {
                        changedFlag = true;  // Mark it as changed if the value is different
                    }
                }
            }
    
            // Highlight changed parameters
            if (changedFlag) {
                row.style.backgroundColor = '#ffcccb';  // Highlight changed rows with a pink background
            }
    
            // Add the "Changed" column to indicate if any changes were found
            var changedCell = document.createElement('td');
            changedCell.textContent = changedFlag ? 'Yes' : 'No';
            row.appendChild(changedCell);
    
            // Add the row to the table
            table.appendChild(row);
    });
    //Function to create a separate table for Version 2 validation
function createMasterValidationTable(allVersions, version) {
    // Get the validation table element
    var table = document.getElementById('validation-master-table');

    // Clear existing table content
    table.innerHTML = '';

    // Create the table header for validation table
    var headerRow = document.createElement('tr');
    var headers = ['Parameter', 'Master Data', 'Version ' + version, 'Validation Status', 'DeepSeek Comments'];

    // Add headers to the table
    headers.forEach(headerText => {
        var th = document.createElement('th');
        th.textContent = headerText;
        headerRow.appendChild(th);
    });
    table.appendChild(headerRow);

    // Collect all parameters (union of all parameters from the version and master data)
    var allParameters = new Set();
    var masterData = getMasterData();  // Assuming you have a function to fetch master data

    for (var param in masterData) {
        allParameters.add(param);
    }

    // Add version 2 extracted data
    for (var param in allVersions[version].extracted_data) {
        allParameters.add(param);
    }

    // Fill in the table rows for master data vs version 2 data
    allParameters.forEach(param => {
        var row = document.createElement('tr');

        // Create a cell for the parameter name
        var paramCell = document.createElement('td');
        paramCell.textContent = param;
        row.appendChild(paramCell);

        // Get the master data and version data
        var masterValue = masterData[param] || 'N/A';
        var versionValue = allVersions[version].extracted_data[param] || 'N/A';

        // Add master data and version 2 data
        var masterDataCell = document.createElement('td');
        masterDataCell.textContent = masterValue;
        row.appendChild(masterDataCell);

        var versionDataCell = document.createElement('td');
        versionDataCell.textContent = versionValue;
        row.appendChild(versionDataCell);

        // Validate data and show status
        var validationStatusCell = document.createElement('td');
        var validationStatus = (masterValue === versionValue) ? 'Valid' : 'Invalid';
        validationStatusCell.textContent = validationStatus;
        row.appendChild(validationStatusCell);

        // Add DeepSeek comment (if available)
        var deepSeekCommentCell = document.createElement('td');
        deepSeekCommentCell.textContent = getDeepSeekComment(param) || 'No comment';  // Assuming a function to fetch comments
        row.appendChild(deepSeekCommentCell);

        // Add the row to the table
        table.appendChild(row);
    });
}   

    // Now, validate the latest version against the master data and add the validation status and DeepSeek comments
    var latestVersion = Object.keys(allVersions).pop();  // Get the latest version (last uploaded version)
    var extractedData = allVersions[latestVersion].extracted_data;
    var validationResults = allVersions[latestVersion].validation_results;

    for (var param in extractedData) {
        // For the latest version, use validation
        var validationStatus = validationResults[param] ? validationResults[param].match ? 'Valid' : 'Invalid' : 'Pending';
        
        // Find the corresponding row in the table and add validation result and DeepSeek comments
        var rows = table.rows;
        for (var i = 1; i < rows.length; i++) {
            var cells = rows[i].cells;
            if (cells[0].textContent === param) {
                // Add the validation result and DeepSeek comment in the last column of that row
                var validationCell = document.createElement('td');
                validationCell.textContent = validationStatus;
                rows[i].appendChild(validationCell);

                // Add DeepSeek comment
                var commentCell = document.createElement('td');
                commentCell.textContent = validationResults[param].comment || 'No comment';
                rows[i].appendChild(commentCell);
                break;
            }
        }
    }
}


    function initResultsPage() {
        if (!window.location.pathname.includes('result.html')) return;

        const termsheetData = JSON.parse(localStorage.getItem('termsheetData') || '{}');
        
        if (Object.keys(termsheetData).length === 0) {
            showNotification('No data available. Please process a termsheet first.', 'error');
            return;
        }

        console.log('Loaded termsheet data:', termsheetData);

        // Handle different response structures
        let extractedData = termsheetData.extracted_data || {};
        let validationResults = termsheetData.validation_results || {};

        // Special case for email/chat access responses
        if (termsheetData.data) {
            extractedData = termsheetData.data.extracted_data || extractedData;
            validationResults = termsheetData.data.validation_results || validationResults;
        }

        // Populate document info
        populateDocumentInfo(extractedData);

        // Process validation data
        if (validationResults && Object.keys(validationResults).length > 0) {
            const validationItems = transformValidationData(validationResults, extractedData);
            console.log('Transformed validation items:', validationItems);
            populateValidationTable(validationItems);
        } else {
            console.log('No validation results found');
            showEmptyValidationTable();
        }
    }

    function transformValidationData(validationResults, extractedData) {
        const validationData = validationResults.validation_results || validationResults;
    
        if (!validationData || typeof validationData !== 'object') {
            console.warn('Invalid validation data format:', validationData);
            return [];
        }
    
        return Object.entries(validationData).map(([param, info]) => {
            const extracted = extractedData[param] || 'N/A';
            const masterList = Array.isArray(info.master_list)
                ? info.master_list.join(', ')
                : '—';
    
            const status = info.match === true ? 'Valid' : 'Invalid';
            const comment = info.comment || '—';
    
            return {
                parameter: param,
                value: extracted,
                master: masterList,
                status: status,
                comment: comment
            };
        });
    }
    

    function populateValidationTable(validationItems) {
        const tbody = document.querySelector('#validation-table tbody');
        if (!tbody) return;
    
        tbody.innerHTML = '';
    
        if (!validationItems || validationItems.length === 0) {
            showEmptyValidationTable();
            return;
        }
    
        validationItems.forEach(item => {
            const row = document.createElement('tr');
    
            // Parameter
            const paramCell = document.createElement('td');
            paramCell.textContent = formatParameterName(item.parameter);
            row.appendChild(paramCell);
    
            // Extracted Value
            const valueCell = document.createElement('td');
            valueCell.textContent = item.value || 'N/A';
            row.appendChild(valueCell);
    
            // Master Values
            const masterCell = document.createElement('td');
            masterCell.textContent = item.master || '—';
            row.appendChild(masterCell);
    
            // Status
            const statusCell = document.createElement('td');
            statusCell.textContent = item.status;
    
            if (item.status.toLowerCase() === 'valid') {
                statusCell.classList.add('status-valid');
            } else {
                statusCell.classList.add('status-invalid');
            }
            row.appendChild(statusCell);
    
            // DeepSeek Comment
            const commentCell = document.createElement('td');
            commentCell.textContent = item.comment || '';
            commentCell.classList.add('comment');
            row.appendChild(commentCell);
    
            tbody.appendChild(row);
        });
    }
    

    function showEmptyValidationTable() {
        const tbody = document.querySelector('#validation-table tbody');
        if (!tbody) return;
        
        const row = document.createElement('tr');
        const cell = document.createElement('td');
        cell.colSpan = 4;
        cell.textContent = 'No validation data available';
        cell.style.textAlign = 'center';
        row.appendChild(cell);
        tbody.appendChild(row);
    }

    // Form handlers
    function handleEmailSubmit(e) {
        e.preventDefault();
        const email = document.getElementById('emailAddress').value;
        const password = document.getElementById('password').value;
        const termsheetId = document.getElementById('termsheetId').value;
        
        if (!email || !password || !termsheetId) {
            showNotification('Please fill in all fields', 'error');
            return;
        }
        
        showLoading('Processing your request...');
        
        fetch(`${API_BASE_URL}/email-access`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, termsheetId })
        })
        .then(handleResponse)
        .then(data => {
            if (data.success) {
                localStorage.setItem('termsheetData', JSON.stringify(data.data));
                window.location.href = 'result.html';
            } else {
                throw new Error(data.error || 'Failed to access via email');
            }
        })
        .catch(error => {
            hideLoading();
            showNotification(error.message || 'Request processing error', 'error');
        });
    }

    function handleChatSubmit(e) {
        e.preventDefault();
        const phone = document.getElementById('phoneNumber').value;
        const otp = document.getElementById('otp').value;
        const termsheetId = document.getElementById('chatTermsheetId').value;
        
        if (!phone || !otp || !termsheetId) {
            showNotification('Please fill in all fields', 'error');
            return;
        }
        
        showLoading('Processing your request...');
        
        fetch(`${API_BASE_URL}/chat-access`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone, otp, termsheetId })
        })
        .then(handleResponse)
        .then(data => {
            if (data.success) {
                localStorage.setItem('termsheetData', JSON.stringify(data.data));
                window.location.href = 'result.html';
            } else {
                throw new Error(data.error || 'Failed to access via chat');
            }
        })
        .catch(error => {
            hideLoading();
            showNotification(error.message || 'Request processing error', 'error');
        });
    }

    function handleFileSelection(file) {
        const validTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        const fileExtension = file.name.split('.').pop().toLowerCase();
        
        if (!validTypes.includes(file.type) && !['pdf', 'docx'].includes(fileExtension)) {
            showNotification('Invalid file type. Please upload a PDF or DOCX file.', 'error');
            return;
        }
        
        if (file.size > 10 * 1024 * 1024) {
            showNotification('File size exceeds 10MB limit.', 'error');
            return;
        }
        
        currentDocument = file;
        showLoading('Processing your TermSheet...');
        
        const formData = new FormData();
        formData.append('file', file);
        
        fetch(`${API_BASE_URL}/upload`, { method: 'POST', body: formData })
            .then(handleResponse)
            .then(data => {
                if (data.success) {
                    localStorage.setItem('termsheetData', JSON.stringify(data));
                    window.location.href = 'result.html';
                } else {
                    throw new Error(data.error || 'Failed to process file');
                }
            })
            .catch(error => {
                hideLoading();
                showNotification(error.message || 'File processing error', 'error');
            });
    }

    function handleTabClick() {
        const tabName = this.getAttribute('data-tab');
        
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        
        this.classList.add('active');
        document.getElementById(tabName + 'Tab').classList.add('active');
    }

    function togglePasswordVisibility() {
        const input = this.previousElementSibling;
        if (input.type === 'password') {
            input.type = 'text';
            this.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            input.type = 'password';
            this.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }

    function exportValidationData() {
        const termsheetData = JSON.parse(localStorage.getItem('termsheetData') || '{}');
        const validationResults = termsheetData.validation_results || 
                                (termsheetData.extracted_data?.validation_results);
        
        if (!validationResults) {
            showNotification('No validation data available to export', 'error');
            return;
        }
        
        const extractedData = termsheetData.extracted_data || {};
        const validationItems = transformValidationData(validationResults, extractedData);
        
        let csvContent = 'Parameter,Extracted Value,Status,Comment\n';
        
        validationItems.forEach(item => {
            csvContent += `"${item.parameter}","${item.value}","${item.status}","${item.comment}"\n`;
        });
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `termsheet_report_${Date.now()}.csv`;
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    function populateDocumentInfo(data) {
        updateElementText('Client', data.client);
        updateElementText('.Issuer', data.issuer);
        
        updateElementText('TradeDate', formatDate(data.trade_date));
        updateElementText('valueDate', formatDate(data.value_date));
        updateElementText('ExpiryDate', formatDate(data.expiry_date));
        updateElementText('DeliveryDate', formatDate(data.delivery_date));
        
        updateElementText('Reference_Spot_Price', formatCurrency(data.ref_spot_price));
        updateElementText('Notional_Amount', formatCurrency(data.notional_amount));
        updateElementText('Strike_Price', formatCurrency(data.strike_price));
        updateElementText('Premium_Rate', data.premium_rate ? data.premium_rate + '%' : 'N/A');
        
        updateElementText('Option_Type', data.option_type);
        updateElementText('Business_Calendar', data.business_calendar);
        updateElementText('Settlements_Type', data.settlement_type || data.settlements_type);
        updateElementText('Settlements_Method', data.settlement_method || data.settlements_method);
        
        updateElementText('Transaction_Currency', data.transaction_ccy);
        updateElementText('Counter_Currency', data.counter_ccy);
    }

    function updateElementText(selector, value) {
        const element = selector.startsWith('.') 
            ? document.querySelector(selector)
            : document.getElementById(selector);
        if (element) element.textContent = value || 'N/A';
    }

    function formatParameterName(param) {
        return param?.replace(/_/g, ' ').replace(/(^|\s)\w/g, match => match.toUpperCase()) || '';
    }

    function formatDate(dateString) {
        if (!dateString) return 'N/A';
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
        } catch (error) {
            return dateString || 'N/A';
        }
    }

    function formatCurrency(value, currency = 'USD') {
        if (!value && value !== 0) return 'N/A';
        try {
            return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(value);
        } catch (error) {
            return value?.toString() || 'N/A';
        }
    }

    function showSection(section) {
        const sections = ['uploadSection', 'emailSection', 'chatSection'];
        sections.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = 'none';
        });
        if (section) section.style.display = 'block';
    }

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function showLoading(message) {
        const loadingOverlay = document.getElementById('loadingOverlay');
        if (loadingOverlay) {
            const messageElement = loadingOverlay.querySelector('p');
            if (messageElement) messageElement.textContent = message || 'Processing...';
            loadingOverlay.style.display = 'flex';
        }
    }

    function hideLoading() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        if (loadingOverlay) loadingOverlay.style.display = 'none';
    }

    function showNotification(message, type = 'info') {
        alert(message); // Replace with a better notification system if needed
    }

    function handleResponse(response) {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || 'Request failed');
            });
        }
        return response.json();
    }
});